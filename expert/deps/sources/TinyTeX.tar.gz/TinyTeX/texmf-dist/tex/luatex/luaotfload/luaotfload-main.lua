-----------------------------------------------------------------------
--         FILE:  luaotfload-main.lua
--  DESCRIPTION:  OpenType layout system / compatibility wrapper
-----------------------------------------------------------------------

return require'luaotfload'
