# Shopware integration

:::warning
Please be aware that those two integrations are not maintained by the BTCPay Server team. If you have any questions, please go to their GitHub issues and contact them directly.
:::

## Plugin for Shopware 6

Download it on [GitHub](https://github.com/coincharge-io/CoinchargeBTCPayShopware)

## Plugin for Shopware 5

Download it on [GitHub](https://github.com/lampsolutions/LampSBtcPayShopware)
