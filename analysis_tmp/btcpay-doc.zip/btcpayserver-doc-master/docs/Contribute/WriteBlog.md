# Contribute to the blog

For the time being, the blog is hosted on Wordpress and the contributing process doesn't require Github.

Simply hit us in the [chat](https://chat.btcpayserver.org) and we'll discuss the writing proposed.

Subjects that are suitable for the blog include:

- BTCPay Server updates
- Tutorials
- Testimonies of how BTCPay Server helped you

Writing articles on our [Blog](https://blog.btcpayserver.org) helps spread the word on new features being implemented, or provides tutorials on how to use them.
